package com.example.hw1.utilities

class Constants {


    companion object {
        val COLUMNS =5
        val ROWS = 10
        const val SLOW_SPEED = 500
        const val FAST_SPEED = 200
        const val SENSOR_MODE = 300
        const val GAME_UPDATE_DELAY = 1000L
        const val DEFAULT_SPEED = SLOW_SPEED

    }
}